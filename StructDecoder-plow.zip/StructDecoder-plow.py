import struct
import binascii



    
def decode_row(data):
    iTime, opt_caltc, opt_bearing, speed, depth, burial_depth, tow_wire_out, tow_wire_tension, pt_skid, stbd_skid, dprsr_height, pitch, roll, heading, dprsr_tension, calc_tw_length, x, y, z, tow_wire_weight, calc_top_tension, calc_heading, status, unused, kp, off_path, umbilical_out, umbilical_tension, altitude, tw_angle_plow, calc_tw_angle, white_space = struct.unpack('<iiidddddddddddddddddddiiddddddd4s', data)

    # Convert the D,H:M:S from the integer value to day, hours, minutes, and seconds
    day = iTime+86400 // (3600 * 24)
    dhms_remainder = iTime % (3600 * 24)
    hours, remainder = divmod(dhms_remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    dhms_str = f"{day:02d}.{hours:02d}:{minutes:02d}:{seconds:02d}"
    return dhms_str, opt_caltc, opt_bearing, speed, depth, burial_depth, tow_wire_out, tow_wire_tension, pt_skid, stbd_skid, dprsr_height, pitch, roll, heading, dprsr_tension, calc_tw_length, x, y, z, tow_wire_weight, calc_top_tension, calc_heading, status, unused, kp, off_path, umbilical_out, umbilical_tension, altitude, tw_angle_plow, calc_tw_angle, white_space

with open('newers dplow.dat', 'rb') as binary_file:

     #Read the first 4 bytes to get the row size
    row_size_bytes = binary_file.read(4)
    row_size = int.from_bytes(row_size_bytes, byteorder='little')
    
    reclen = (row_size-1) * 4
    # Skip to the start of the second row
    binary_file.seek(4+reclen, 0)
    
    num_records_bytes = binary_file.read(4)
    num_records = int.from_bytes(num_records_bytes, byteorder='little')
    binary_file.seek(8+(reclen*2), 0)
    
    actual_row_size = (row_size) * 4
    
    #testing data, if the buffer doesn't fit
    # print(row_size)
    # print(num_records)
    #print(actual_row_size)

    with open('struct-output-25aug23(1).txt', 'w') as output_file:  # Open a text file for writing
        txt = "num_record, hms_str, opt_caltc, opt_bearing, speed, depth, burial_depth, tow_wire_out, tow_wire_tension, pt_skid, stbd_skid, dprsr_height, pitch, roll, heading, dprsr_tension, calc_tw_length, x, y, z, tow_wire_weight, calc_top_tension, calc_heading, status, unused, kp, off_path, umbilical_out, umbilical_tension, altitude, tw_angle_plow, calc_tw_angle, unknown_data'\n"
        output_file.write(txt)
        for _ in range(num_records):
            #testing 100 head data
            # if _ == 100:
                    # break
            # Read one record of data
            data = binary_file.read(actual_row_size)

            formatted_data = str(decode_row(data))

            # Write the hexadecimal data to the output file

            #output_file.write(f'Record {_}:\n') optional
            output_file.write(f"Record {_},{formatted_data}'\n")

            print(f'Record {_}')
